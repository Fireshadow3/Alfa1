/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prova;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.*;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author Fabio
 */
public class FXMLDocumentController implements Initializable {
    @FXML
    private TextField scoreTextField;
    @FXML
    private TextField timeMinTextField;
    @FXML
    private TextField timeSecTextField;
    @FXML
    private TextField wordFromKeyboardTextField;
    @FXML
    private TextArea wordsFoundTextArea;
    @FXML
    private Button letter1Button;
    @FXML
    private Button letter2Button;
    @FXML
    private Button letter3Button;
    @FXML
    private Button letter4Button;
    @FXML
    private Button letter5Button;
    @FXML
    private Button letter6Button;
    @FXML
    private Button letter7Button;
    @FXML
    private ChoiceBox difficultyChoice;
    
    public void handleButtonAction(Event event) { 
        
    }
    
    public void keyPressed(KeyEvent event) {
        
    }
    
    public void handleChoiceBoxClicked(Event event){
        difficultyChoice.show();
    }
    
    public void timerInitializing(String difficulty){
        if(difficulty.equalsIgnoreCase("easy")){
            timeMinTextField.setText("2");
            timeSecTextField.setText("00");
        }else if(difficulty.equalsIgnoreCase("hard")){
            timeMinTextField.setText("1");
            timeSecTextField.setText("00");
        }else{
            timeMinTextField.setText("1");
            timeSecTextField.setText("30");
        }
    }
       
    public int timeDecrease(){
        int min = Integer.parseInt(timeMinTextField.getText()),
                sec = Integer.parseInt(timeSecTextField.getText());
        if (min == 0 && sec == 0)
            return min;
        else if (min > 0 && sec - 1 < 0){
            min -= 1;
            sec += 59; 
        }
        timeMinTextField.setText("" + min);
        timeSecTextField.setText("" + sec);
        timeDecrease();
        return sec;
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Management man = new Management("in.txt", "out.txt");
        man.deleteWordsAfterSlashCharacter();
        String word = man.wordGenerationFromRandomLetters(letter1Button.getText(),
                letter1Button.getText(), letter1Button.getText(), 
                letter1Button.getText(), letter1Button.getText(),
                letter1Button.getText(), letter1Button.getText());
        ArrayList<String> wordsWithSevenCharacters = man.wordOfSevenCharacterInDictionary(word);
        if (wordsWithSevenCharacters.isEmpty()){
                    scoreTextField.setEditable(false);
        timeMinTextField.setEditable(false);
        timeSecTextField.setEditable(false);
        wordFromKeyboardTextField.setEditable(false);
        wordsFoundTextArea.setDisable(true);
        letter1Button.setDisable(true);
        letter2Button.setDisable(true);
        letter3Button.setDisable(true);
        letter4Button.setDisable(true);
        letter5Button.setDisable(true);
        letter6Button.setDisable(true);
        letter7Button.setDisable(true); 
        }
            
        /* ChoiceBox difficultyChoice = new ChoiceBox();
        difficultyChoice.setItems(FXCollections.observableArrayList
        ("New Document", "Open ", new Separator(), "Save", "Save as"));
        scoreTextField.setEditable(false);
        timeMinTextField.setEditable(false);
        timeSecTextField.setEditable(false);
        wordFromKeyboardTextField.setEditable(false);
        wordsFoundTextArea.setDisable(true);
        letter1Button.setDisable(true);
        letter2Button.setDisable(true);
        letter3Button.setDisable(true);
        letter4Button.setDisable(true);
        letter5Button.setDisable(true);
        letter6Button.setDisable(true);
        letter7Button.setDisable(true); */
    }    
    
}
