/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prova;

/**
 *
 * @author Fabio
 */
public interface Constants {
    static final int MAX_LENGTH = 11;
    static final int MIN_LENGTH = 8;
    static final int MAX_LENGTH_TO_FILE = 7;
    static final int MIN_LENGTH_TO_FILE = 3;
    static final String ENCODING = "ISO-8859-1";
    // numero minimo per metodo substringAnagramsForWordLengthGreaterThanThree()
    static final int MIN_LENGTH_ANAG = 3;
    static final String BUTTON_COLOR = "-fx-background-color: #ff471a";
}
