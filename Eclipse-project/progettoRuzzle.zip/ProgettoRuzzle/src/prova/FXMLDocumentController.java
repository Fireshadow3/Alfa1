/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prova;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.*;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
/**
 *
 * @author Fabio
 */
public class FXMLDocumentController implements Initializable {
    @FXML
    private CheckBox easyDifficultCheckBox;
    @FXML
    private CheckBox mediumDifficultCheckBox;
    @FXML
    private CheckBox hardDifficultCheckBox;
    @FXML
    private TextField scoreTextField;
    @FXML
    private TextField timeMinTextField;
    @FXML
    private TextField timeSecTextField;
    @FXML
    private TextField wordFromKeyboardTextField;
    @FXML
    private TextArea wordsFoundTextArea;
    @FXML
    private Button letter1Button;
    @FXML
    private Button letter2Button;
    @FXML
    private Button letter3Button;
    @FXML
    private Button letter4Button;
    @FXML
    private Button letter5Button;
    @FXML
    private Button letter6Button;
    @FXML
    private Button letter7Button;
    
    public void handleButtonAction(Event event) { 
        
    }
    
    public void handleEasyCheckBoxAction(ActionEvent event){
    }
    
    public void keyPressed(KeyEvent event) {
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        scoreTextField.setEditable(false);
        timeMinTextField.setEditable(false);
        timeSecTextField.setEditable(false);
        wordFromKeyboardTextField.setEditable(false);
        letter1Button.setDisable(true);
        letter2Button.setDisable(true);
        letter3Button.setDisable(true);
        letter4Button.setDisable(true);
        letter5Button.setDisable(true);
        letter6Button.setDisable(true);
        letter7Button.setDisable(true);
    }    
    
}
