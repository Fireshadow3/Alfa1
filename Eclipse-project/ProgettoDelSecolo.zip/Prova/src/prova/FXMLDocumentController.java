/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prova;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import java.util.*;
/**
 *
 * @author Fabio
 */
public class FXMLDocumentController implements Initializable {
    @FXML
    private TextArea anagramTextArea;
    @FXML
    private TextField anagramTextField; 
    @FXML
    private Label label;
    
    @FXML
    public void handleButtonAction(ActionEvent event) {
        Management man = new Management("", "");
        ArrayList<String> anag = man.anagramGenerator(anagramTextField.getText());
        anagramTextField.setEditable(false); // rendo il testo non ulteriormente modificabile
        String result = "";
        for(String s : anag)
            result += (s + "\n");
        anagramTextArea.setText(result);
        anagramTextArea.setEditable(false);
    }
    
    public void keyPressed(ActionEvent event) {
        // da implementare il metodo per chiamare anagram
        // generator in seguito alla pressione del tasto
        // INVIO 
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
