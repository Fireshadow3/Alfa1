/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prova;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.*;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import java.util.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
/**
 *
 * @author Fabio
 */
public class FXMLDocumentController implements Initializable {
    @FXML
    private TextArea anagramTextArea;
    @FXML
    private TextField anagramTextField; 
    @FXML
    private Label label;
    
    @FXML
    public void handleButtonAction(Event event) { 
        Management man = new Management("C:\\Users\\user\\Downloads\\Alfa1-master\\Alfa1-master\\Eclipse-project\\Prova\\src\\in.txt",
                "C:\\Users\\user\\Downloads\\Alfa1-master\\Alfa1-master\\Eclipse-project\\Prova\\src\\out.txt");
        ArrayList<String> dic = man.deleteWordsAfterSlashCharacter();
        ArrayList<String> anag = man.anagramGenerator
            (anagramTextField.getText());
        String result = "";
        System.out.println(anag);
        /*
        for (String s : dic) {
            for (String s1 : anag) {
                if (s.equals(s1))
                    result += (s + "\n");
            }
        }
        // result = anag.stream().map((s) -> (s + "\n")).reduce(result, String::concat);
        anagramTextArea.setText(result);
        // rendo il testo della textArea non ulteriormente modificabile
        anagramTextArea.setEditable(false);
*/
    }
    
    public void keyPressed(KeyEvent event) {
        if(event.getCode() == KeyCode.ENTER)
             handleButtonAction(event);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
